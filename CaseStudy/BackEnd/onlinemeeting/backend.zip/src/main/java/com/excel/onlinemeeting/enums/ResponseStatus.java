package com.excel.onlinemeeting.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public enum ResponseStatus {

		ACCEPT("ACCEPT"), DECLINE("DECLINE"),ACCEPTED("ACCEPTED"), DECLINED("DECLINED");

		private final String responseStatus ;
}
