package com.excel.onlinemeeting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinemeetingApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinemeetingApplication.class, args);
	}

}
