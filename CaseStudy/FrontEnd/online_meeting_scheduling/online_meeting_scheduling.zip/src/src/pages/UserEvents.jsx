import React, { useEffect, useState } from "react";
import axios from "axios";
import { Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import NavBar from '../components/NavBar';
import '../../src/style/table.css';

function UserEvents() {

const [meetingDetails, setMeetingDetails] = useState([]);

useEffect(() => {
  getMeetingDetails();
}, []);

const getMeetingDetails = async () => {
  try {
    const response = await axios.get("http://localhost:8080/onlinemeeting/getall");
    if (response.data && Array.isArray(response.data)) {
      setMeetingDetails(response.data);
    } else {
      console.error("Invalid response data format.");
      setMeetingDetails([]);
    }
  } catch (error) {
    console.error("Error fetching meeting details: ", error);
    setMeetingDetails([]);
  }
};

return (
  <div>
    <NavBar />
    <div className="adminevents">
      <h1 className="eventheading">Upcoming Meetings</h1>
      <table className="custom-table">
        <thead>
          <tr>
            <th>Meeting ID</th>
            <th>Title</th>
            <th>Agenda</th>
            <th>Date</th>
            <th>Time</th>
            <th colSpan={'2'}>Action</th>
          </tr>
        </thead>
        <tbody>
          {meetingDetails.map((meeting, index) => (
            <tr key={index}>
              <td>{meeting.meetingId}</td>
              <td>{meeting.title}</td>
              <td>{meeting.agenda}</td>
              <td>{meeting.date}</td>
              <td>{meeting.time}</td>
              <td>
                <div style={{display:"flex",flexDirection:"row", paddingLeft:'100px', marginLeft:"120px"}}>
                 
                  <Button variant="outline-success" style={{ width: '100px', marginRight:"100px"}}>Accepted</Button>&nbsp;
                 
                  <Button variant="outline-danger" style={{ width: '120px',  marginRight:"100px"}}>Declined</Button> &nbsp;
                  <Button variant="outline-warning" style={{ width: '120px', marginRight:"100px"}}>Pending</Button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);
}

export default UserEvents;


// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import { Button, Modal } from "react-bootstrap";
// import { ToastContainer, toast } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';
// import NavBar from '../components/NavBar';
// import '../../src/style/table.css';

// function UserEvents() {
//   const [meetingDetails, setMeetingDetails] = useState([]);
//   const [showModal, setShowModal] = useState(false);

//   useEffect(() => {
//     getMeetingDetails();
//   }, []);

//   const getMeetingDetails = async () => {
//     try {
//       const response = await axios.get("http://localhost:8080/onlinemeeting/getall");
//       if (response.data && Array.isArray(response.data)) {
//         setMeetingDetails(response.data);
//       } else {
//         console.error("Invalid response data format.");
//         setMeetingDetails([]);
//       }
//     } catch (error) {
//       console.error("Error fetching meeting details: ", error);
//       setMeetingDetails([]);
//     }
//   };

//   const handleAccept = () => {
//     // Display modal when the "Accepted" button is clicked
//     setShowModal(true);
//   };

//   return (
//     <div>
//       <NavBar />
//       <ToastContainer />
//       <div className="adminevents">
//         <h1 className="eventheading">Meeting Details</h1>
//         <table className="custom-table">
//           <thead>
//             <tr>
//               <th>Meeting ID</th>
//               <th>Title</th>
//               <th>Agenda</th>
//               <th>Date</th>
//               <th>Time</th>
//               <th colSpan={'2'}>Action</th>
//             </tr>
//           </thead>
//           <tbody>
//             {meetingDetails.map((meeting, index) => (
//               <tr key={index}>
//                 <td>{meeting.meetingId}</td>
//                 <td>{meeting.title}</td>
//                 <td>{meeting.agenda}</td>
//                 <td>{meeting.date}</td>
//                 <td>{meeting.time}</td>
//                 <td>
//                   <div style={{display:"flex",flexDirection:"row", paddingLeft:'100px', marginLeft:"120px"}}>
//                     <Button variant="outline-success" style={{ width: '100px', marginRight:"100px"}} onClick={handleAccept} >Accepted</Button>&nbsp;
//                     <Button variant="outline-danger" style={{ width: '120px',  marginRight:"100px"}}>Declined</Button> &nbsp;
//                     <Button variant="outline-warning" style={{ width: '120px', marginRight:"100px"}}>Pending</Button>
//                   </div>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       </div>

//       {/ Modal for "You are in the meeting!" message /}
//       <Modal show={showModal} onHide={() => setShowModal(false)}>
//         <Modal.Header closeButton>
//           <Modal.Title>You are in the meeting!</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>
//           You have successfully accepted the meeting.
//         </Modal.Body>
//         <Modal.Footer>
//           <Button variant="secondary" onClick={() => setShowModal(false)}>
//             Close
//           </Button>
//         </Modal.Footer>
//       </Modal>
//     </div>
//   );
// }

// export default UserEvents;
