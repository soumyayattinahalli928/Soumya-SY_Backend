import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import '../../src/style/updatemeeting.css';

const UpdateMeeting = () => {
  const { meetingId } = useParams(); // Get the meetingId from URL params

  const [meetingDetails, setMeetingDetails] = useState({
    meetingId: '', 
    date: '',
    title: '',
    agenda: '',
    time: ''
  });

  useEffect(() => {
    getMeetingDetails(meetingId); // Fetch meeting details based on the meetingId
  }, [meetingId]);

  const getMeetingDetails = async (meetingId) => {
    try {
      const response = await axios.get(`http://localhost:8080/onlinemeeting/get/${meetingId}`);
      if (response.data) {
        setMeetingDetails(response.data);
      } else {
        console.error("Meeting not found.");
      }
    } catch (error) {
      console.error("Error fetching meeting details: ", error);
    }
  };

  const handleUpdateMeeting = async (e) => {
    e.preventDefault(); 
    try {
      const response = await axios.put(
        `http://localhost:8080/onlinemeeting/update/${meetingId}`, // Use meetingId in the URL
        meetingDetails
      );
      console.log("Meeting updated:", response.data);
      alert("Meeting Updated Successfully");
    } catch (error) {
      console.error("Error updating meeting:", error);
    }
  };

  return (
    <div className='update-meeting'>
      <h1 className='update-meeting-heading'>Update Meeting</h1>
      <div className='update-meeting-form-container'>
        <Form onSubmit={handleUpdateMeeting}>
          {/* Your form inputs */}
          <Button type='submit' className='updatebtn'>Update Meeting</Button>
          <br /><br />
          <Link to="/adminevents">
            <Button variant="primary" className='updatebtn'>Back</Button>
          </Link>
        </Form>
      </div>
    </div>
  );
}

export default UpdateMeeting;
