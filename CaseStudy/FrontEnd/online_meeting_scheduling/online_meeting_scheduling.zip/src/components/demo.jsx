import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';
import { Formik } from 'formik';
import * as yup from 'yup';
import axios from 'axios';
import NavBar from '../components/NavBar';
import '../../src/style/adminregistration.css';

const AdminRegistration = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phoneNo: '',
    email: '',
    password: '',
    role: '', // Added role field
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value,
    }));
  };

  const schema = yup.object().shape({
    firstName: yup.string().required(),
    lastName: yup.string().required(),
    phoneNo: yup.string().required(),
    email: yup.string().required(),
    password: yup.string().required(),
    role: yup.string().required(), // Validate role field
  });

  const registerUser = () => {
    axios
      .post("http://localhost:8080/onlinemeeting/saveuser", formData)
      .then((res) => {
        console.log(res.data);
        alert("Registration successful"); // Display pop-up message
      })
    //   .catch((error) => {
    //     console.error('Error registering user:', error);
    //     // Handle error cases if needed
    //   });
  };

  return (
    <>
      <NavBar />
      <br />
      <Formik
        validationSchema={schema}
        onSubmit={(values) => {
          console.log(values);
          registerUser(); // Call registerUser function on form submission
        }}
        initialValues={{
          firstName: '',
          lastName: '',
          phoneNo: '',
          email: '',
          password: '',
          role: '', // Initialize role field
        }}
      >
        {({ handleSubmit, values, touched, errors }) => (
          <>
            <h1 style={{ marginTop: '200px', color: 'ivory' }}>Registration Form</h1>
            <br />
            <div className='adreg'>
              <div className='form'>
                <Form noValidate onSubmit={handleSubmit}>
                  <Row className='mb-1'>
                    <Form.Label className='labelcolor'>Role</Form.Label>
                    <Form.Select
                      aria-label="Default select example"
                      style={{ width: '70%' }}
                      onChange={(event) =>
                        setFormData({ ...formData, role: event.target.value })
                      }
                      value={formData.role}
                    >
                      <option>-----select role----</option>
                      <option value="User">User</option>
                      <option value="Admin">Admin</option>
                    </Form.Select>
                  </Row>
                  {/* Other form fields */}
                  <br />
                  <Button type='submit'>Submit</Button>
                </Form>
              </div>
            </div>
          </>
        )}
      </Formik>
    </>
  );
}

export default AdminRegistration;
