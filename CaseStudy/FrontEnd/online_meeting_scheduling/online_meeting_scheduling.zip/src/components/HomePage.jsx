import React from 'react';
import '../../src/style/homepage.css';
function HomePage() {
    return (
     <div className="homeimg ms">
       <h1 className='heading'>Online Meeting Scheduling App</h1>
     </div>
       
    );
}
export default HomePage;