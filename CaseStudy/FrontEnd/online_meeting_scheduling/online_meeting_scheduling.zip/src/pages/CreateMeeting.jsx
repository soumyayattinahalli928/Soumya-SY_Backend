import React, { useEffect, useState } from 'react'
import { Form } from 'react-bootstrap'
import Button from 'react-bootstrap/Button'
import { Link } from 'react-router-dom'
import '../../src/style/createmeeting.css';
import NavBar from '../components/NavBar'
import axios from 'axios';

const CreateMeeting = () => {

  const meeting = (formData) => {
    axios
      .post("http://localhost:8080/onlinemeeting/savemeeting", formData)
      .then((res) => console.log(res.data))
      .catch((error) => console.error("Error creating meeting: ", error));
  };

  // const getApi = () => {
  //   axios.get("http://localhost:8080/onlinemeeting/get/1")
  //     .then((res) => console.log(res.data))
  //     .catch((error) => console.error("Error fetching meeting: ", error));
  // }

  // useEffect(() => {
  //   getApi();
  // }, []);

  const [formData, setFormData] = useState({
    meetingId: '',
    title: '',
    agenda: '',
    date: '',
    time: '',
  })

  return (
    <div className='meeting'>
      <NavBar /><br /><br />
      <div className='desc-container'>
        <h1 className='mh'>Meeting Details</h1><br />
        <Form style={{ marginLeft: '40%' }}>

          <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
            <Form.Label className="lable"><h5>Title:</h5></Form.Label>
            <Form.Control
              onChange={(event) =>
                setFormData({ ...formData, title: event.target.value })
              }
              name='title'
              type="text" className="input" />
          </Form.Group>

          <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
            <Form.Label className="lable"><h5>Agenda:</h5></Form.Label>
            <Form.Control
              onChange={(event) =>
                setFormData({ ...formData, agenda: event.target.value })
              }
              name='agenda'
              as="textarea" rows={3} className="input" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
            <Form.Label className="lable"><h5>Meeting Date:</h5></Form.Label>
            <Form.Control
              onChange={(event) =>
                setFormData({ ...formData, date: event.target.value })
              }
              name='date'
              type="date" className="input" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
            <Form.Label className="lable"><h5>Meeting Start Time:</h5></Form.Label>
            <Form.Control
              onChange={(event) =>
                setFormData({ ...formData, time: event.target.value })
              }
              name='time'
              type="time" className="input" />
          </Form.Group>
       
          <Button variant="danger">
            <Link to="/" className='link' style={{ color: 'white', textDecoration: 'none' }}>Back</Link>
          </Button>{' '}
          <br />
          <Button variant="success" onClick={() => meeting(formData)} style={{ marginTop: '20px' }}>
            <Link to="/adminevents" className='link' style={{ color: 'white', textDecoration: 'none' }}>Create Meeting</Link>
          </Button>{' '}

        </Form>
      </div>
    </div>
  );
}

export default CreateMeeting;

